<?php
$_debug = false;
//The allowed extensions for this script
$extension_whitelist = array('docx', 'xlsx', 'pdf');
//define an array containing the possible errors when uploading a file
$uploadErrors = array(
    0 => "There is no error, the file uploaded with success.",
    1 => "The uploaded file exceeds the upload_max_filesize directive in php.ini",
    2 => "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.",
    3 => "The uploaded file was only partially uploaded.",
    4 => "No file was uploaded.",
    6 => "Missing a temporary folder."
);

//Test the following: a file is uploaded; no upload error have occured; the uploaded file is found; the file have a name
if (!isset($_FILES['office_file'])) {
    $result = "3. No upload found in \$_FILES for 'office_file'";
 
    if ($_debug == "true") {
        echo $result . "<br />" . $returnlink;
        error_reporting(E_ALL ^ E_NOTICE);
    } else {
        header($return, true, 302);
        echo $result . "<br />" . $returnlink;
    }
    exit(0);
} elseif (isset($_FILES['office_file']["error"]) && $_FILES['office_file']["error"] != 0) {
    $returndata = $uploadErrors[$_FILES['office_file']["error"]];
    $result = "4. " . $returndata;
  
    if ($_debug == "true") {
        echo $result . "<br />" . $returnlink;
        error_reporting(E_ALL ^ E_NOTICE);
    } else {
        header($return, true, 302);
        echo $result . "<br />" . $returnlink;
    }
    exit(0);
} elseif (!isset($_FILES['office_file']["tmp_name"]) || !@is_uploaded_file($_FILES['office_file']["tmp_name"])) {
    $result = "5. Upload failed is_uploaded_file test.";
 
    if ($_debug == "true") {
        echo $result . "<br />" . $returnlink;
        error_reporting(E_ALL ^ E_NOTICE);
    } else {
        header($return, true, 302);
        echo $result . "<br />" . $returnlink;
    }
    exit(0);
} elseif (!isset($_FILES['office_file']['name'])) {
    $result = "6. File has no name.";
 
    if ($_debug == "true") {
        echo $result . "<br />" . $returnlink;
        error_reporting(E_ALL ^ E_NOTICE);
    } else {
        header($return, true, 302);
        echo $result . "<br />" . $returnlink;
    }
    exit(0);
}

//check if the file is in the correct size limitations
$file_size = @filesize($_FILES['office_file']["tmp_name"]);
$file_name = $_FILES['office_file']['name'];
if (!$file_size) {
    $result = "7. File exceeds the maximum allowed size.";

    if ($_debug == "true") {
        echo $result . "<br />" . $returnlink;
        error_reporting(E_ALL ^ E_NOTICE);
    } else {
        header($return, true, 302);
        echo $result . "<br />" . $returnlink;
    }
    exit(0);
}

if ($file_size <= 0) {
    $result = "8. File size outside allowed lower bound.";
   
    if ($_debug == "true") {
        echo $result . "<br />" . $returnlink;
        error_reporting(E_ALL ^ E_NOTICE);
    } else {
        header($return, true, 302);
        echo $result . "<br />" . $returnlink;
    }
    exit(0);
}
//check if the file have the correct extension
$filepath = $_FILES['office_file']['name'];
$tempfile = $_FILES['office_file']['tmp_name'];
$path_info = pathinfo($filepath);
$file_extension = $path_info["extension"];
$is_valid_extension = false;
foreach ($extension_whitelist as $extension) {
    if (strtolower($file_extension) == $extension) {
        $is_valid_extension = true;
        break;
    }
}
if (!$is_valid_extension) {
    $result = "9. Invalid file extension.";
    if ($_debug == "true") {
        echo $result . "<br />" . $returnlink;
        error_reporting(E_ALL ^ E_NOTICE);
    } else {
        header($return, true, 302);
        echo $result . "<br />" . $returnlink;
    }
    exit(0);
}



require("../YiiOffice.php");

$YiiOffice = new YiiOffice($tempfile,$_debug);
echo $YiiOffice->getHtml();