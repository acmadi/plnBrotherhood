<form action="upload.php"  method="post"  enctype = "multipart/form-data">
	<label>Select File:</label>
	<input type="file" name="office_file" />
	<input type="submit" name="send" />
</form>	